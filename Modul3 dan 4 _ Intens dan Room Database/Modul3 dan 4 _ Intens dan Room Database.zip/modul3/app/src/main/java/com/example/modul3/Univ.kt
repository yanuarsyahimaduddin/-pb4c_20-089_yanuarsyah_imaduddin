package com.example.modul3

data class Univ (
    var name: String = ""


)